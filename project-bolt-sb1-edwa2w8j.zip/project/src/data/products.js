export const products = [
  {
    id: 1,
    name: "Classic Running Shoes",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
    category: "running",
    description: "Perfect for long-distance running with superior cushioning"
  },
  {
    id: 2,
    name: "Urban Sneakers",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2",
    category: "casual",
    description: "Stylish and comfortable for everyday wear"
  },
  {
    id: 3,
    name: "Sport Elite",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5",
    category: "sport",
    description: "High-performance athletic shoes for serious athletes"
  },
  {
    id: 4,
    name: "Casual Comfort",
    price: 69.99,
    image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77",
    category: "casual",
    description: "Ultimate comfort for casual occasions"
  },
  {
    id: 5,
    name: "Trail Blazer",
    price: 119.99,
    image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa",
    category: "running",
    description: "Designed for tough trail running conditions"
  },
  {
    id: 6,
    name: "Basketball Pro",
    price: 139.99,
    image: "https://images.unsplash.com/photo-1605348532760-6753d2c43329",
    category: "sport",
    description: "Professional-grade basketball shoes"
  },
  {
    id: 7,
    name: "Street Style",
    price: 84.99,
    image: "https://images.unsplash.com/photo-1560769629-975ec94e6a86",
    category: "casual",
    description: "Modern street fashion with attitude"
  },
  {
    id: 8,
    name: "Marathon Elite",
    price: 149.99,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a",
    category: "running",
    description: "Engineered for marathon performance"
  }
];