<script>
  let email = '';
  let password = '';
  let confirmPassword = '';
  let name = '';

  function handleRegister(event) {
    event.preventDefault();
    // Add registration logic here
    console.log('Registration attempt:', { name, email, password });
  }
</script>

<div class="register-container">
  <form class="register-form" on:submit={handleRegister}>
    <h2>Create Account</h2>
    
    <div class="form-group">
      <label for="name">Full Name</label>
      <input 
        type="text" 
        id="name" 
        bind:value={name} 
        required
      />
    </div>

    <div class="form-group">
      <label for="email">Email</label>
      <input 
        type="email" 
        id="email" 
        bind:value={email} 
        required
      />
    </div>

    <div class="form-group">
      <label for="password">Password</label>
      <input 
        type="password" 
        id="password" 
        bind:value={password} 
        required
      />
    </div>

    <div class="form-group">
      <label for="confirm-password">Confirm Password</label>
      <input 
        type="password" 
        id="confirm-password" 
        bind:value={confirmPassword} 
        required
      />
    </div>

    <button type="submit">Register</button>
    
    <p class="login-link">
      Already have an account? <a href="/login">Login here</a>
    </p>
  </form>
</div>

<style>
  .register-container {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #000;
  }

  .register-form {
    background: rgba(0, 0, 0, 0.8);
    padding: 2.5rem;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(255, 215, 0, 0.2);
    width: 100%;
    max-width: 400px;
    border: 1px solid #FFD700;
  }

  h2 {
    text-align: center;
    margin-bottom: 2rem;
    color: #FFD700;
    font-size: 2rem;
  }

  .form-group {
    margin-bottom: 1.5rem;
  }

  label {
    display: block;
    margin-bottom: 0.5rem;
    color: #FFD700;
  }

  input {
    width: 100%;
    padding: 0.75rem;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid #FFD700;
    border-radius: 4px;
    color: #FFF;
    transition: all 0.3s;
  }

  input:focus {
    outline: none;
    border-color: #FFF;
    box-shadow: 0 0 5px rgba(255, 215, 0, 0.5);
  }

  button {
    width: 100%;
    padding: 0.75rem;
    background: #FFD700;
    color: #000;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    margin-top: 1.5rem;
    transition: all 0.3s;
  }

  button:hover {
    background: #FFF;
    transform: translateY(-2px);
  }

  .login-link {
    text-align: center;
    margin-top: 1.5rem;
    color: #FFF;
  }

  .login-link a {
    color: #FFD700;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s;
  }

  .login-link a:hover {
    color: #FFF;
  }
</style>