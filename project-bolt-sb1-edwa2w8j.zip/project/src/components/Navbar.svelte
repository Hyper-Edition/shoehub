<script>
  let isMenuOpen = false;

  function toggleMenu() {
    isMenuOpen = !isMenuOpen;
  }
</script>

<nav class="navbar">
  <div class="logo">
    <a href="/">ShoesHub</a>
  </div>
  
  <button class="menu-button" on:click={toggleMenu}>
    <span class="menu-icon"></span>
  </button>

  <div class="nav-links" class:active={isMenuOpen}>
    <a href="/">Home</a>
    <a href="/shop">Shop</a>
    <a href="/login">Login</a>
    <a href="/register">Register</a>
  </div>
</nav>

<style>
  .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 2rem;
    background: #000000;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  .logo a {
    font-size: 1.5rem;
    font-weight: bold;
    color: #FFD700;
    text-decoration: none;
  }

  .nav-links {
    display: flex;
    gap: 2rem;
  }

  .nav-links a {
    color: #FFD700;
    text-decoration: none;
    font-weight: 500;
  }

  .nav-links a:hover {
    color: #FFF;
  }

  .menu-button {
    display: none;
  }

  @media (max-width: 768px) {
    .menu-button {
      display: block;
      background: #FFD700;
    }

    .nav-links {
      display: none;
    }

    .nav-links.active {
      display: flex;
      flex-direction: column;
      position: absolute;
      top: 60px;
      left: 0;
      right: 0;
      background: #000;
      padding: 1rem;
    }
  }
</style>