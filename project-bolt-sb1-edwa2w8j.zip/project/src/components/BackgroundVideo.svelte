<script>
  export let videoUrl;
  export let fallbackImage;
</script>

<div class="video-container">
  <video autoplay loop muted playsinline>
    <source src={videoUrl} type="video/mp4">
    <img src={fallbackImage} alt="Fallback background" />
  </video>
</div>

<style>
  .video-container {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    z-index: -1;
  }

  video {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
</style>