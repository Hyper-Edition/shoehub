<script>
  import { fade, scale } from 'svelte/transition';
  import { quintOut } from 'svelte/easing';
  
  export let product;
  export let onClose;
</script>

<div class="overlay" 
  on:click={onClose} 
  transition:fade={{duration: 200}}>
  <div class="popup"
    on:click|stopPropagation
    transition:scale={{duration: 300, easing: quintOut}}>
    <button class="close-btn" on:click={onClose}>&times;</button>
    
    <div class="product-content">
      <div class="product-image">
        <img src={product.image} alt={product.name} />
      </div>
      
      <div class="product-details">
        <h2>{product.name}</h2>
        <p class="description">{product.description}</p>
        <p class="price">${product.price}</p>
        
        <div class="additional-info">
          <div class="info-item">
            <span class="label">Category:</span>
            <span class="value">{product.category}</span>
          </div>
          <div class="info-item">
            <span class="label">Available:</span>
            <span class="value">In Stock</span>
          </div>
        </div>
        
        <button class="add-to-cart">Add to Cart</button>
      </div>
    </div>
  </div>
</div>

<style>
  .overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  }

  .popup {
    background: #000;
    border: 2px solid #FFD700;
    border-radius: 12px;
    padding: 2rem;
    max-width: 900px;
    width: 90%;
    position: relative;
    color: #FFF;
  }

  .close-btn {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: none;
    border: none;
    color: #FFD700;
    font-size: 2rem;
    cursor: pointer;
    padding: 0;
    line-height: 1;
  }

  .product-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
  }

  .product-image img {
    width: 100%;
    height: auto;
    border-radius: 8px;
  }

  .product-details h2 {
    color: #FFD700;
    margin: 0 0 1rem 0;
  }

  .description {
    color: #CCC;
    margin-bottom: 1.5rem;
    line-height: 1.6;
  }

  .price {
    font-size: 1.5rem;
    color: #FFD700;
    font-weight: bold;
    margin-bottom: 1.5rem;
  }

  .additional-info {
    margin-bottom: 2rem;
  }

  .info-item {
    margin-bottom: 0.5rem;
  }

  .label {
    color: #FFD700;
    margin-right: 0.5rem;
  }

  .value {
    color: #FFF;
  }

  .add-to-cart {
    width: 100%;
    padding: 1rem;
    background: #FFD700;
    color: #000;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s;
  }

  .add-to-cart:hover {
    background: #FFF;
  }

  @media (max-width: 768px) {
    .product-content {
      grid-template-columns: 1fr;
    }
  }
</style>