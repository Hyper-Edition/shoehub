<script>
  export let selectedCategory = 'all';
  export let onSelectCategory;

  const categories = ['all', 'running', 'casual', 'sport'];
</script>

<div class="category-filter">
  {#each categories as category}
    <button 
      class:active={selectedCategory === category}
      on:click={() => onSelectCategory(category)}>
      {category.charAt(0).toUpperCase() + category.slice(1)}
    </button>
  {/each}
</div>

<style>
  .category-filter {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-bottom: 2rem;
  }

  button {
    padding: 0.5rem 1rem;
    border: 2px solid #FFD700;
    background: transparent;
    color: #FFD700;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s;
  }

  button:hover {
    background: #FFD700;
    color: #000;
  }

  button.active {
    background: #FFD700;
    color: #000;
  }
</style>