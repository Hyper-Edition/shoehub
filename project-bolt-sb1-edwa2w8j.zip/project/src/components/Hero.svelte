<script>
  import BackgroundVideo from './BackgroundVideo.svelte';
  
  let heroTitle = "Step into Style";
  let heroSubtitle = "Discover our latest collection of trendy shoes";
  let videoUrl = "https://static.videezy.com/system/resources/previews/000/046/556/original/200723_01_Urban_Dance_4k.mp4";
  let fallbackImage = "/images/hero-bg.jpg";
</script>

<section class="hero">
  <BackgroundVideo {videoUrl} {fallbackImage} />
  <div class="overlay"></div>
  <div class="hero-content">
    <h1 class="animate-title">{heroTitle}</h1>
    <p class="animate-subtitle">{heroSubtitle}</p>
    <a href="/shop" class="cta-button animate-button">Shop Now</a>
  </div>
</section>

<style>
  .hero {
    height: 90vh;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: white;
    overflow: hidden;
  }

  .overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      rgba(0, 0, 0, 0.7),
      rgba(0, 0, 0, 0.5)
    );
    z-index: 0;
  }

  .hero-content {
    position: relative;
    z-index: 1;
    padding: 2rem;
  }

  .animate-title {
    font-size: 4.5rem;
    margin-bottom: 1rem;
    color: #FFD700;
    opacity: 0;
    animation: slideUp 1s ease forwards;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  }

  .animate-subtitle {
    font-size: 1.8rem;
    margin-bottom: 2rem;
    opacity: 0;
    animation: slideUp 1s ease 0.3s forwards;
  }

  .cta-button {
    display: inline-block;
    padding: 1rem 3rem;
    background: #FFD700;
    color: #000;
    text-decoration: none;
    border-radius: 50px;
    font-weight: bold;
    font-size: 1.2rem;
    transition: all 0.3s;
    opacity: 0;
    animation: slideUp 1s ease 0.6s forwards;
    border: 2px solid #FFD700;
  }

  .cta-button:hover {
    background: transparent;
    color: #FFD700;
    transform: translateY(-3px);
    box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
  }

  @keyframes slideUp {
    from {
      transform: translateY(30px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }

  @media (max-width: 768px) {
    .animate-title {
      font-size: 3rem;
    }
    
    .animate-subtitle {
      font-size: 1.4rem;
    }
  }
</style>