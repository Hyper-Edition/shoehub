<script>
  import { createEventDispatcher } from 'svelte';
  export let product;
  
  const dispatch = createEventDispatcher();
  
  function handleClick() {
    dispatch('select', product);
  }
</script>

<div class="product-card" on:click={handleClick}>
  <img src={product.image} alt={product.name} />
  <div class="product-info">
    <h3>{product.name}</h3>
    <p class="description">{product.description}</p>
    <p class="price">${product.price}</p>
    <button class="add-to-cart" on:click|stopPropagation>Add to Cart</button>
  </div>
</div>

<style>
  .product-card {
    background: #000;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(255,215,0,0.2);
    overflow: hidden;
    transition: all 0.3s;
    color: #FFF;
    cursor: pointer;
  }

  .product-card:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 4px 8px rgba(255,215,0,0.3);
  }

  img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s;
  }

  .product-card:hover img {
    transform: scale(1.05);
  }

  .product-info {
    padding: 1rem;
  }

  h3 {
    margin: 0 0 0.5rem 0;
    font-size: 1.2rem;
    color: #FFD700;
  }

  .description {
    color: #CCC;
    font-size: 0.9rem;
    margin: 0.5rem 0;
    height: 2.7em;
    overflow: hidden;
  }

  .price {
    color: #FFD700;
    font-weight: bold;
    margin: 0.5rem 0;
  }

  .add-to-cart {
    width: 100%;
    padding: 0.5rem;
    background: #FFD700;
    color: #000;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.3s;
    font-weight: bold;
  }

  .add-to-cart:hover {
    background: #FFF;
  }
</style>