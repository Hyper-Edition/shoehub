<script>
  import ProductCard from './ProductCard.svelte';
  import ProductDetailPopup from './ProductDetailPopup.svelte';
  import CategoryFilter from './CategoryFilter.svelte';
  import { products } from '../data/products';
  
  let selectedCategory = 'all';
  let selectedProduct = null;
  
  $: filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  function handleCategorySelect(category) {
    selectedCategory = category;
  }

  function handleProductSelect(event) {
    selectedProduct = event.detail;
  }

  function closePopup() {
    selectedProduct = null;
  }
</script>

<section class="products-section">
  <h2>Featured Products</h2>
  <CategoryFilter 
    {selectedCategory} 
    onSelectCategory={handleCategorySelect} 
  />
  <div class="product-grid">
    {#each filteredProducts as product}
      <ProductCard 
        {product} 
        on:select={handleProductSelect}
      />
    {/each}
  </div>
</section>

{#if selectedProduct}
  <ProductDetailPopup 
    product={selectedProduct} 
    onClose={closePopup}
  />
{/if}

<style>
  .products-section {
    padding: 2rem;
    background: #111;
  }

  h2 {
    text-align: center;
    margin-bottom: 2rem;
    color: #FFD700;
  }

  .product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 2rem;
    max-width: 1200px;
    margin: 0 auto;
  }
</style>