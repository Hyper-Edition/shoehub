<script>
  import Navbar from './components/Navbar.svelte';
  import Hero from './components/Hero.svelte';
  import ProductGrid from './components/ProductGrid.svelte';
  import { Router, Link, Route } from "svelte-routing";
  import Login from './routes/Login.svelte';
  import Register from './routes/Register.svelte';

  export let url = "";
</script>

<Router {url}>
  <main>
    <Navbar />
    
    <Route path="/" component={Hero} />
    <Route path="/login" component={Login} />
    <Route path="/register" component={Register} />
  </main>
</Router>

{#if window.location.pathname === '/'}
  <ProductGrid />
{/if}

<style>
  :global(body) {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
      Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  }

  main {
    width: 100%;
    min-height: 100vh;
  }
</style>